#!/usr/bin/env python
# coding: utf-8

# In[7]:


get_ipython().system('pip install --force-reinstall scikit-learn==1.2.2')
get_ipython().system('pip install --force-reinstall numpy==1.26.4')


# In[1]:


import sklearn, numpy
print("sklearn:", sklearn.__version__)
print("numpy:", numpy.__version__)


# In[2]:


# [1] train model（use sklearn 1.2.2）
import pandas as pd
import joblib
import boto3
from sklearn.ensemble import RandomForestClassifier
from sklearn.preprocessing import MultiLabelBinarizer
from sklearn.model_selection import train_test_split

# S3 setting
bucket = 'job-matching-group1'
key = 'clean/sampled_jobs.csv'
s3 = boto3.client('s3')

# 1. Download S3 data
print("downloading...")
response = s3.get_object(Bucket=bucket, Key=key)
data = pd.read_csv(response['Body'])
print(f"successes, total {len(data)} data")
data['job_skills'] = data['job_skills'].apply(lambda x: [s.strip() for s in str(x).split(',')])


mlb = MultiLabelBinarizer()
X = mlb.fit_transform(data['job_skills'])
y = data['job_title']

# train model
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)

# save models
joblib.dump(model, 'job_title_model_v4.pkl')
joblib.dump(mlb, 'skill_binarizer_v4.pkl')

s3.upload_file('job_title_model_v4.pkl', bucket, 'model/job_title_model_v4.pkl')
s3.upload_file('skill_binarizer_v4.pkl', bucket, 'model/skill_binarizer_v4.pkl')
print("model and binarized have been uploaded to S3")


# In[11]:


inference_code6 = """
import joblib
import json
import os

def model_fn(model_dir):
    model = joblib.load(os.path.join(model_dir, "job_title_model_v4.pkl"))
    binarizer = joblib.load(os.path.join(model_dir, "skill_binarizer_v4.pkl"))
    return (model, binarizer)

def input_fn(request_body, content_type='application/json'):
    if content_type == 'application/json':
        return json.loads(request_body)
    raise ValueError("Unsupported content type")

def predict_fn(input_data, model_binarizer):
    model, binarizer = model_binarizer
    job_skills = input_data['job_skills']
    expected_title = input_data.get('expected_title')

    vector = binarizer.transform([job_skills])
    prediction = model.predict(vector)[0]

    proba = model.predict_proba(vector)[0]
    classes = model.classes_

    matching_score = None
    if expected_title and expected_title in classes:
        idx = list(classes).index(expected_title)
        matching_score = float(proba[idx])

    return {
        'predicted_job_title': prediction,
        'expected_title': expected_title,
        'matching_score': matching_score
    }

def output_fn(prediction, content_type='application/json'):
    return json.dumps(prediction)
"""
with open("inference6.py", "w") as f:
    f.write(inference_code6)


# In[12]:


import tarfile

with tarfile.open("model_v6.tar.gz", "w:gz") as tar:
    tar.add("job_title_model_v4.pkl")
    tar.add("skill_binarizer_v4.pkl")
    tar.add("inference6.py")

s3 = boto3.client('s3')
s3.upload_file("model_v6.tar.gz", "job-matching-group1", "model/model_v6.tar.gz")


# In[13]:


from sagemaker.sklearn.model import SKLearnModel
import sagemaker
import time
import boto3

print("🔧 初始化 SageMaker Session...")
sagemaker_session = sagemaker.Session()
role = 'arn:aws:iam::739875578321:role/LabRole'

print("preparing model data...")
model = SKLearnModel(
    model_data='s3://job-matching-group1/model/model_v6.tar.gz',
    role=role,
    entry_point='inference6.py',
    framework_version='1.2-1',
    sagemaker_session=sagemaker_session
)

print("start to use SageMaker Endpoint (around 5-10 mins)...")
predictor = model.deploy(
    initial_instance_count=1,
    instance_type='ml.m5.large',
    endpoint_name='job-title-endpoint-v6'
)

print("waiting Endpoint to finish")
sm_client = boto3.client('sagemaker')
endpoint_name = 'job-title-endpoint-v6'

while True:
    status = sm_client.describe_endpoint(EndpointName=endpoint_name)['EndpointStatus']
    print(f"Status：{status}")
    if status in ['InService', 'Failed']:
        break
    time.sleep(30)

if status == 'InService':
    print("SageMaker Endpoint has succeeded！Endpoint is ready")
else:
    failure_reason = sm_client.describe_endpoint(EndpointName=endpoint_name).get('FailureReason', 'no detail reason')
    print(f" SageMaker Endpoint is failed, reason：{failure_reason}")


# In[14]:


import boto3
import json

# build SageMaker Runtime
runtime = boto3.client('sagemaker-runtime')

# simulate one skills to input data
test_input = {
    "job_skills": [
        "Communication", "Python", "AWS", "Teamwork", "Project Management"
    ]
}

# call SageMaker Endpoint
response = runtime.invoke_endpoint(
    EndpointName='job-title-endpoint-v5',
    ContentType='application/json',
    Body=json.dumps(test_input)
)

# predict result
result = json.loads(response['Body'].read().decode('utf-8'))
print("predict result：", result)

