import pandas as pd
data = pd.read_csv("cleaned_jobs.csv", on_bad_lines='skip', engine="python")
print("raw data count：", len(data))

# 2. process the column "job_skills" to split into list
data['job_skills'] = data['job_skills'].apply(lambda x: [skill.strip() for skill in str(x).split(',')])

# 3. filter and retain >=20 job_title count
title_counts = data['job_title'].value_counts()
valid_titles = title_counts[title_counts >= 20].index
filtered_data = data[data['job_title'].isin(valid_titles)].reset_index(drop=True)

print("retain job title count：", filtered_data['job_title'].nunique())

# 4. random sampling 1000 data
sampled_data = filtered_data.sample(n=1000, random_state=42).reset_index(drop=True)

# 5. save CSV fiel
sampled_data.to_csv("sampled_jobs.csv", index=False)
print("store sampled_jobs.csv successfully (total 1000 data)")