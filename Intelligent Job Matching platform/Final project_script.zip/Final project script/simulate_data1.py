import boto3
import json
import uuid
import random
from datetime import datetime

# 設定
STREAM_NAME = 'incoming-job-stream'
REGION = 'us-east-1'
kinesis = boto3.client('kinesis', region_name=REGION)

# 範例資料池
job_titles = ["Software Developer", "Data Analyst", "Project Manager", "Cyber Security Analyst"]
job_skills_pool = ["Python", "SQL", "AWS", "Excel", "Project Management", "Communication", "Security", "JavaScript"]
expected_titles = ["Software Engineer", "Business Analyst", "Product Manager", "Security Engineer"]

# 產生 3 筆模擬資料
for i in range(3):
    job_event = {
        "job_id": f"cli-batch-{uuid.uuid4()}",
        "timestamp": datetime.utcnow().isoformat(),
        "job_title": random.choice(job_titles),
        "job_skills": random.sample(job_skills_pool, k=random.randint(4, 6)),
        "expected_title": random.choice(expected_titles)
    }

    # 寫入 Kinesis
    kinesis.put_record(
        StreamName=STREAM_NAME,
        Data=json.dumps(job_event),
        PartitionKey=job_event['job_title']
    )

    print(f"✅ Sent mock job: {job_event['job_id']} | title: {job_event['job_title']} | expected: {job_event['expected_title']}")