import json
import boto3
import pandas as pd
import io

def lambda_handler(event, context):
    s3 = boto3.client('s3')
    bucket = "job-matching-group1"

    # 1. Read two datasets
    metadata_obj = s3.get_object(Bucket=bucket, Key="raw/linkedin_job_postings.csv")
    skills_obj = s3.get_object(Bucket=bucket, Key="raw/job_skills.csv")

    metadata_df = pd.read_csv(metadata_obj['Body'])
    skills_df = pd.read_csv(skills_obj['Body'])

    # 2. Clean column names
    metadata_df.columns = [col.strip().lower() for col in metadata_df.columns]
    skills_df.columns = [col.strip().lower() for col in skills_df.columns]

    # 3. combine data
    merged_df = pd.merge(metadata_df, skills_df, on="job_link", how="left")

    # 4. clean null
    merged_df.dropna(subset=["job_title", "company", "job_skills"], inplace=True)

    # 5. standardize job_level、job_type
    merged_df["job_level"] = merged_df["job_level"].str.title()
    merged_df["job_type"] = merged_df["job_type"].str.title()

    # 6. Store into S3 (csv file)
    output_buffer = io.StringIO()
    merged_df.to_csv(output_buffer, index=False)
    s3.put_object(Bucket=bucket, Key="clean/cleaned_jobs.csv", Body=output_buffer.getvalue())


    return {
        'statusCode': 200,
        'body': json.dumps('Job data cleaned and saved to S3.')
    }