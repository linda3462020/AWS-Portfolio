import boto3
import csv
import io
from datetime import datetime
from decimal import Decimal

DDB_TABLE = 'PredictedJobEvents'
S3_BUCKET = 'job-matching-output-group1'

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table(DDB_TABLE)
s3 = boto3.client('s3')

def lambda_handler(event, context):
    print("start to sync PredictedJobEvents to S3...")

    # 1. scan the whole DynamoDB table
    all_items = []
    response = table.scan()
    all_items.extend(response.get('Items', []))

    while 'LastEvaluatedKey' in response:
        response = table.scan(ExclusiveStartKey=response['LastEvaluatedKey'])
        all_items.extend(response.get('Items', []))

    print(f"total get {len(all_items)} data")

    if not all_items:
        return {"statusCode": 200, "body": "no data to sync"}

    # 2. write into csv file
    csv_buffer = io.StringIO()
    writer = csv.DictWriter(
        csv_buffer,
        fieldnames=['job_id', 'predicted_title', 'expected_title', 'matching_score', 'job_skills', 'timestamp'],
        quoting=csv.QUOTE_ALL
    )
    writer.writeheader()

    for item in all_items:
        writer.writerow({
            'job_id': item.get('job_id'),
            'predicted_title': item.get('predicted_title'),
            'expected_title': item.get('expected_title'),
            'matching_score': float(item.get('matching_score')) if item.get('matching_score') is not None else None,
            'job_skills': ', '.join(item.get('job_skills', [])),
            'timestamp': item.get('timestamp')
        })

    # 3. update to S3 and use timestamp to be file name
    timestamp_str = datetime.utcnow().strftime("%Y-%m-%d-%H-%M")
    key = f'all_predictions/all_predictions-{timestamp_str}.csv'

    s3.put_object(
        Bucket=S3_BUCKET,
        Key=key,
        Body=csv_buffer.getvalue()
    )

    print(f"s3://{S3_BUCKET}/{key}")

    return {
        "statusCode": 200,
        "body": f"successed to sync {len(all_items)} data to S3：{key}"
    }