import json
import base64
import boto3
import uuid
from decimal import Decimal

dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('UnpredictedJobEvents')

def lambda_handler(event, context):
    for record in event['Records']:
        try:
            # 1. decode Kinesis data
            payload = base64.b64decode(record['kinesis']['data'])
            decoded_str = payload.decode('utf-8')
            data = json.loads(decoded_str, parse_float=Decimal)

            # 2. if lack job_id, add it
            if 'job_id' not in data:
                data['job_id'] = str(uuid.uuid4())

            # 3. Add the predict status
            data['predicted'] = False

            # 4. Write into DynamoDB
            table.put_item(Item=data)
            print(f"✅ Inserted job_id: {data['job_id']} | title: {data.get('job_title')}")

        except Exception as e:
            print(f"❌ Error processing record: {e}")