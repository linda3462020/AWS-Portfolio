import json
import boto3
from datetime import datetime
import csv
import io
from decimal import Decimal

UNPREDICTED_TABLE = 'UnpredictedJobEvents'
PREDICTED_TABLE = 'PredictedJobEvents'
S3_BUCKET = 'job-matching-output-group1'
ENDPOINT_NAME = 'job-title-endpoint-v6'

dynamodb = boto3.resource('dynamodb')
unpredicted_table = dynamodb.Table(UNPREDICTED_TABLE)
predicted_table = dynamodb.Table(PREDICTED_TABLE)
sagemaker = boto3.client('sagemaker-runtime')
s3 = boto3.client('s3')

def lambda_handler(event, context):
    response = unpredicted_table.scan()
    items = response.get('Items', [])
    print(f"🔍 Found {len(items)} unpredicted items.")

    if not items:
        return {"statusCode": 200, "body": "No unpredicted items."}

    all_results = []

    for job in items:
        try:
            job_id = job.get('job_id')
            job_skills = job.get('job_skills', [])
            expected_title = job.get('expected_title')

            print(f"📦 Predicting job_id: {job_id} | expected: {expected_title}")

            # combine input data
            payload = {'job_skills': job_skills}
            if expected_title:
                payload['expected_title'] = expected_title

            sm_response = sagemaker.invoke_endpoint(
                EndpointName=ENDPOINT_NAME,
                ContentType='application/json',
                Body=json.dumps(payload)
            )

            result = json.loads(sm_response['Body'].read().decode('utf-8'))
            predicted_title = result.get('predicted_job_title')
            matching_score = result.get('matching_score')
            timestamp = datetime.utcnow().isoformat()

            # revise float to Decimal
            if matching_score is not None:
                matching_score = Decimal(str(matching_score))

            print(f"🤖 Prediction result: {predicted_title} | score: {matching_score}")

            # write into DynamoDB（PredictedJobEvents）
            predicted_table.put_item(Item={
                'job_id': job_id,
                'job_skills': job_skills,
                'predicted_title': predicted_title,
                'expected_title': expected_title,
                'matching_score': matching_score,
                'timestamp': timestamp
            })

            all_results.append({
                'job_id': job_id,
                'predicted_title': predicted_title,
                'expected_title': expected_title,
                'matching_score': float(matching_score) if matching_score is not None else None,
                'job_skills': ', '.join(job_skills),
                'timestamp': timestamp
            })

            # delete the data have been processed
            unpredicted_table.delete_item(Key={'job_id': job_id})
            print(f"🧹 Deleted job_id: {job_id}")

        except Exception as e:
            print(f"❌ Failed to process job_id={job.get('job_id')}: {str(e)}")

    # write into the csv file
    if all_results:
        csv_buffer = io.StringIO()
        writer = csv.DictWriter(csv_buffer, fieldnames=[
            'job_id', 'predicted_title', 'expected_title', 'matching_score', 'job_skills', 'timestamp'
        ])
        writer.writeheader()
        writer.writerows(all_results)

        timestamp_filename = datetime.utcnow().isoformat().replace(":", "-") + ".csv"
        s3.put_object(
            Bucket=S3_BUCKET,
            Key=f'predictions/{timestamp_filename}',
            Body=csv_buffer.getvalue()
        )
        print(f"✅ Uploaded CSV: {timestamp_filename} with {len(all_results)} rows")
    else:
        print("⚠️ No prediction results to write to CSV.")

    return {
        "statusCode": 200,
        "body": json.dumps({
            "message": f"Processed {len(all_results)} jobs"
        })
    }